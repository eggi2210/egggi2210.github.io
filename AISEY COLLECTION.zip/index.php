<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>AISEY COLLECTION </title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="header">
    <p>AISEY COLLECTION</p>
  </div>
  <nav>
    <ul> <?php include("page/navbar.php") ?> </ul>
  </nav>
  <?php include("content.php") ?>
  <?php include("page/user/keranjang.php") ?>
  <div class="footer">
    <p>copyright by | pace | Repost by <a href="" target="_blank">Framework Id</a></p>
  </div>
</body>
</html>